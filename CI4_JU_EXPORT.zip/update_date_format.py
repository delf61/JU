import os
import glob
import re

files = glob.glob('ci4_app/app/Views/**/*.php', recursive=True)

for filepath in files:
    with open(filepath, 'r') as file:
        content = file.read()
        
    # Replace simple date formats
    content = content.replace("'d.m.Y'", "'Y.m.d'")
    content = content.replace('"d.m.Y"', '"Y.m.d"')
    
    with open(filepath, 'w') as file:
        file.write(content)

print("Date formats updated to Y.m.d")
