import re

with open("ci4_app/app/Views/cashbook/summary.php", "r") as f:
    content = f.read()

content = content.replace(
    '<div class="col-left tree-line" style="flex:1;"> SC</div>\n            <div class="col" style="flex:1;">0.00</div>',
    '<div class="col-left tree-line" style="flex:1;"> SC</div>\n            <div class="col" style="flex:1;"><?= number_format($summary[\'sc_spolu\'] ?? 0, 2, \'.\', \'\') ?></div>'
)

with open("ci4_app/app/Views/cashbook/summary.php", "w") as f:
    f.write(content)
