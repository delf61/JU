import re

# 1. BankStatementModel
with open("ci4_app/app/Models/BankStatementModel.php", "r") as f:
    content = f.read()

content = content.replace("protected $primaryKey = 'b';", "protected $primaryKey = 'PK';")
content = content.replace("protected $useAutoIncrement = false;", "protected $useAutoIncrement = true;")

# Allow 'PK' field
content = content.replace("'a', 'b',", "'PK', 'a', 'b',")

with open("ci4_app/app/Models/BankStatementModel.php", "w") as f:
    f.write(content)


# 2. BankStatementController
with open("ci4_app/app/Controllers/BankStatementController.php", "r") as f:
    ctrl = f.read()

new_ctrl = """    public function uiEdit()
    {
        return redirect()->back()->with('error', 'Editácia výpisu nie je zatiaľ implementovaná.');
    }

    public function uiDelete()
    {
        $pk = $this->request->getPost('PK');
        if (empty($pk)) {
            return redirect()->back()->with('error', 'Chýbajú dáta pre vymazanie.');
        }

        $db = \Config\Database::connect();
        
        try {
            $db->table('ucet')->where('PK', $pk)->delete();
            return redirect()->back()->with('success', 'Záznam bol úspešne vymazaný.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Chyba pri mazaní: ' . $e->getMessage());
        }
    }

    public function uiCopy()
    {
        $pk = $this->request->getPost('PK');
        if (empty($pk)) {
            return redirect()->back()->with('error', 'Chýbajú dáta pre kópiu.');
        }

        $db = \Config\Database::connect();
        $record = $db->table('ucet')->where('PK', $pk)->get()->getRowArray();
        
        if ($record) {
            unset($record['PK']); // Odstranime PK, aby databaza vygenerovala nove
            
            try {
                $db->table('ucet')->insert($record);
                return redirect()->back()->with('success', 'Záznam bol úspešne skopírovaný 1:1.');
            } catch (\Exception $e) {
                return redirect()->back()->with('error', 'Chyba pri kopírovaní: ' . $e->getMessage());
            }
        }
        
        return redirect()->back()->with('error', 'Presný záznam pre kópiu nebol nájdený v databáze.');
    }"""

start = ctrl.find('public function uiEdit()')
if start != -1:
    end = ctrl.find('return redirect()->back()->with(\'error\', \'Presný záznam pre kópiu nebol nájdený v databáze. Skontrolujte integritu dát.\');\n    }', start)
    end += len('return redirect()->back()->with(\'error\', \'Presný záznam pre kópiu nebol nájdený v databáze. Skontrolujte integritu dát.\');\n    }')
    ctrl = ctrl[:start] + new_ctrl + ctrl[end:]

with open("ci4_app/app/Controllers/BankStatementController.php", "w") as f:
    f.write(ctrl)


# 3. View 
with open("ci4_app/app/Views/bank/index.php", "r") as f:
    view = f.read()

new_actions = r"""                <td class="text-center">
                    <form action="<?= site_url("bank/edit") ?>" method="post" style="display:inline;">
                        <input type="hidden" name="PK" value="<?= esc($row['PK'] ?? '') ?>">
                        <button type="submit" class="btn-action" style="background:#ffc107; color:#000; border:none; cursor:pointer;">Editovať</button>
                    </form>
                    
                    <form action="<?= site_url("bank/copy") ?>" method="post" style="display:inline;">
                        <input type="hidden" name="PK" value="<?= esc($row['PK'] ?? '') ?>">
                        <button type="submit" class="btn-action" style="background:#17a2b8; color:#fff; border:none; cursor:pointer;" >Kópia</button>
                    </form>

                    <form action="<?= site_url("bank/delete") ?>" method="post" style="display:inline;">
                        <input type="hidden" name="PK" value="<?= esc($row['PK'] ?? '') ?>">
                        <button type="submit" class="btn-action" style="background:#dc3545; color:#fff; border:none; cursor:pointer;" onclick="return confirm('Naozaj vymazať tento záznam?');">Vymazať</button>
                    </form>
                </td>"""

start_view = view.find('<td class="text-center">\n                    <?php \n                        // Encode all fields as hidden inputs to ensure 100% exact matching')
end_view = view.find('</td>', start_view) + 5

if start_view != -1 and end_view != -1:
    view = view[:start_view] + new_actions + view[end_view:]

with open("ci4_app/app/Views/bank/index.php", "w") as f:
    f.write(view)

