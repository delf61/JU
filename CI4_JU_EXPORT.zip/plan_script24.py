# Creating the statistics view
with open("ci4_app/app/Views/cashbook/statistics.php", "w") as f:
    f.write("""
<!DOCTYPE html>
<html lang="sk">
<head>
    <meta charset="UTF-8">
    <title>Štatistika (pStatist)</title>
    <style>
        body { font-family: sans-serif; margin: 20px; }
        table { border-collapse: collapse; width: 60%; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: right; }
        th { background-color: #f2f2f2; text-align: center; }
        .text-left { text-align: left; }
    </style>
</head>
<body>
    <h1>Štatistika za rok <?= esc($year) ?> (pStatist)</h1>
    <a href="<?= site_url('cashbook') ?>?year=<?= esc($year) ?>">Späť na Peňažný denník</a>
    
    <table>
        <thead>
            <tr>
                <th class="text-left">Mesiac</th>
                <th>Príjmy celkom</th>
                <th>Výdavky celkom</th>
                <th>Zisk / Strata</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($stats as $month => $data): ?>
            <tr>
                <td class="text-left"><?= $month ?>. mesiac</td>
                <td><?= number_format($data['income'], 2, '.', '') ?></td>
                <td><?= number_format($data['expense'], 2, '.', '') ?></td>
                <td><strong><?= number_format($data['income'] - $data['expense'], 2, '.', '') ?></strong></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
    """)

# Creating the summary view
with open("ci4_app/app/Views/cashbook/summary.php", "w") as f:
    f.write("""
<!DOCTYPE html>
<html lang="sk">
<head>
    <meta charset="UTF-8">
    <title>Sumár po akt. pol. (pPDsuma)</title>
    <style>
        body { font-family: sans-serif; margin: 20px; }
        table { border-collapse: collapse; width: 60%; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .text-right { text-align: right; }
    </style>
</head>
<body>
    <h1>Sumár po akt. pol. za rok <?= esc($year) ?> (pPDsuma)</h1>
    <a href="<?= site_url('cashbook') ?>?year=<?= esc($year) ?>">Späť na Peňažný denník</a>
    
    <table>
        <tbody>
            <tr>
                <th>Príjmy celkom</th>
                <td class="text-right"><?= number_format($summary['prijmy_celkom'], 2, '.', '') ?></td>
            </tr>
            <tr>
                <th>Výdavky celkom</th>
                <td class="text-right"><?= number_format($summary['vydaje_celkom'], 2, '.', '') ?></td>
            </tr>
            <tr>
                <th>Z toho DPH (Výdaj)</th>
                <td class="text-right"><?= number_format($summary['dph_vydaj'], 2, '.', '') ?></td>
            </tr>
            <tr>
                <th>Základ dane</th>
                <td class="text-right"><strong><?= number_format($summary['zaklad_dane'], 2, '.', '') ?></strong></td>
            </tr>
        </tbody>
    </table>
</body>
</html>
    """)
