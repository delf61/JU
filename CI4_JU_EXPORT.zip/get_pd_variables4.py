import re

with open("PRINTER.TXT", "rb") as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    try:
        decoded = line.decode('cp1250', errors='ignore')
        if 'ok :=' in decoded or 'ok:=' in decoded:
            continue
        if ' ok' in decoded and '{' not in decoded and '}' not in decoded and 'kontr' not in decoded:
            start = max(0, i - 1)
            end = min(len(lines), i + 2)
            for j in range(start, end):
                print(lines[j].decode('cp1250', errors='ignore').strip())
            print("\n")
    except:
        pass
