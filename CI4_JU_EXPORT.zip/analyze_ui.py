import re

with open("PRINTER.TXT", "rb") as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    try:
        decoded = line.decode('cp1250', errors='ignore')
        if 'ePDbrowse' in decoded or 'Hot.pr' in decoded or 'K˘dy oper' in decoded or 'Upratovanie' in decoded:
            start = max(0, i - 5)
            end = min(len(lines), i + 10)
            print(f"--- Match at line {i} ---")
            for j in range(start, end):
                print(lines[j].decode('cp1250', errors='ignore').strip())
            print("\n")
    except:
        pass
