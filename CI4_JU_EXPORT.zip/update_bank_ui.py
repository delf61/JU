import re

# 1. Update Controller
with open("ci4_app/app/Controllers/BankStatementController.php", "r") as f:
    controller_content = f.read()

new_methods = r"""    public function webIndex()
    {
        // Parameter roka uchovame len pre tlacidlo "Spat", dopyt bude bez filtra
        $year = $this->request->getGet('year') ?: date('Y');

        // All entries across all years
        $entries = $this->bankService->getEntries(null);
        
        return view('bank/index', [
            'entries' => $entries,
            'year' => $year
        ]);
    }

    public function uiEdit($b, $date)
    {
        // Placeholder for edit view
        return redirect()->back()->with('error', 'Editácia výpisu nie je zatiaľ implementovaná.');
    }

    public function uiDelete($b, $date)
    {
        // Placeholder for delete logic
        return redirect()->back()->with('error', 'Mazanie výpisu nie je zatiaľ implementované.');
    }

    public function uiCopy($b, $date)
    {
        // Basic copy logic
        $db = \Config\Database::connect();
        $record = $db->table('ucet')->where('b', base64_decode($b))->where('d', base64_decode($date))->get()->getRowArray();
        
        if ($record) {
            // Append _COPY to the document number to prevent primary key collision if applicable
            $record['b'] = substr($record['b'] . '_COPY', 0, 8); // b is A,8 in FAND
            
            try {
                $db->table('ucet')->insert($record);
                return redirect()->back()->with('success', 'Záznam bol úspešne skopírovaný.');
            } catch (\Exception $e) {
                return redirect()->back()->with('error', 'Chyba pri kopírovaní: ' . $e->getMessage());
            }
        }
        
        return redirect()->back()->with('error', 'Záznam pre kópiu nebol nájdený.');
    }
}
"""

# V controller_content nahradime celu funkciu
start_idx = controller_content.find('public function webIndex()')
if start_idx != -1:
    controller_content = controller_content[:start_idx] + new_methods

with open("ci4_app/app/Controllers/BankStatementController.php", "w") as f:
    f.write(controller_content)

# 3. Update Routes
with open("ci4_app/app/Config/Routes.php", "r") as f:
    routes_content = f.read()

new_routes = """// Bank Statement
$routes->get('bank', 'BankStatementController::webIndex');
$routes->get('bank/edit/(:any)/(:any)', 'BankStatementController::uiEdit/$1/$2');
$routes->post('bank/delete/(:any)/(:any)', 'BankStatementController::uiDelete/$1/$2');
$routes->post('bank/copy/(:any)/(:any)', 'BankStatementController::uiCopy/$1/$2');"""

routes_content = routes_content.replace("// Bank Statement\n$routes->get('bank', 'BankStatementController::webIndex');", new_routes)

with open("ci4_app/app/Config/Routes.php", "w") as f:
    f.write(routes_content)

# 4. Update View
with open("ci4_app/app/Views/bank/index.php", "r") as f:
    view_content = f.read()

# Header table
view_content = view_content.replace(
    '<th>Popis operácie</th>\n                <th class="text-right">Čiastka<br>€</th>\n                <th class="text-center">C</th>\n                <th class="text-center">P</th>\n            </tr>',
    '<th>Popis operácie</th>\n                <th class="text-right">Čiastka<br>€</th>\n                <th class="text-center">C</th>\n                <th class="text-center">P</th>\n                <th class="text-center">Akcie</th>\n            </tr>'
)

# Body table
row_html = """                <td class="text-center"><?= !empty($row['qa']) ? 'A' : 'N' ?></td>
                <td class="text-center">
                    <?php 
                        $enc_b = base64_encode($row['b']);
                        $enc_d = base64_encode($row['d']); 
                    ?>
                    <a href="<?= site_url("bank/edit/$enc_b/$enc_d") ?>" class="btn-action" style="background:#ffc107; color:#000;">Editovať</a>
                    
                    <form action="<?= site_url("bank/copy/$enc_b/$enc_d") ?>" method="post" style="display:inline;">
                        <button type="submit" class="btn-action" style="background:#17a2b8; color:#fff; border:none; cursor:pointer;" onclick="return confirm('Naozaj vytvoriť kópiu tohto záznamu?');">Kópia</button>
                    </form>

                    <form action="<?= site_url("bank/delete/$enc_b/$enc_d") ?>" method="post" style="display:inline;">
                        <button type="submit" class="btn-action" style="background:#dc3545; color:#fff; border:none; cursor:pointer;" onclick="return confirm('Naozaj vymazať tento záznam?');">Vymazať</button>
                    </form>
                </td>
            </tr>"""
            
view_content = re.sub(r'<td class="text-center"><\?= !empty\(\$row\[\'qa\'\]\) \? \'A\' : \'N\' \?></td>\n            </tr>', row_html, view_content)

# Page length DataTables
view_content = view_content.replace('pageLength: 10', 'pageLength: 20')

# Title tweak to specify ALL years
view_content = view_content.replace('<h1>Bankové výpisy (Ucet) - Rok <?= esc($year) ?></h1>', '<h1>Bankové výpisy (Ucet) - Všetky roky</h1>')

# Flash messages
flash_html = """    <div class="header">
        <h1>Bankové výpisy (Ucet) - Všetky roky</h1>
        <a href="<?= site_url('cashbook') ?>?year=<?= esc($year) ?>" class="btn-back">Späť na Peňažný denník</a>
    </div>

    <?php if (session()->getFlashdata('success')): ?>
        <div style="color: #28a745; margin-bottom: 15px; font-weight: bold;"><?= esc(session()->getFlashdata('success')) ?></div>
    <?php endif; ?>
    <?php if (session()->getFlashdata('error')): ?>
        <div style="color: #dc3545; margin-bottom: 15px; font-weight: bold;"><?= esc(session()->getFlashdata('error')) ?></div>
    <?php endif; ?>"""

view_content = view_content.replace("""    <div class="header">
        <h1>Bankové výpisy (Ucet) - Všetky roky</h1>
        <a href="<?= site_url('cashbook') ?>?year=<?= esc($year) ?>" class="btn-back">Späť na Peňažný denník</a>
    </div>""", flash_html)

# Add basic btn-action styling
style_html = """        .text-center { text-align: center; }
        .btn-action { padding: 4px 8px; border-radius: 3px; font-size: 0.85em; text-decoration: none; margin: 0 2px; display: inline-block; }
    </style>"""
view_content = view_content.replace("        .text-center { text-align: center; }\n    </style>", style_html)


with open("ci4_app/app/Views/bank/index.php", "w") as f:
    f.write(view_content)

