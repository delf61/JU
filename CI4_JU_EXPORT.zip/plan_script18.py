# The user wants to fully migrate all procedures mentioned in the bottom menu to CI4 (controllers, models, views).
# The procedures are:
# pPDkod (categorization split)
# pVyd_Bez_Kod (filter for uncategorized expenses)
# pAktualDatum (change working date/filter)
# pPD_Doklad (open linked document, e.g., SC/invoice)
# pStatist (Statistics report)
# pPDsuma (Running totals report)

# Let's outline the plan. We need to create:
# - CashbookController methods for these actions.
# - CashbookService methods to handle the business logic (e.g. running pPDsuma).
# - Views for the reports (e.g., statistics, pdsuma).
# - Update the index.php UI to link to these actual endpoints instead of JS alerts.
