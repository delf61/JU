import re

with open("ci4_app/app/Views/cashbook/index.php", "r") as f:
    content = f.read()

# Replace the specific div with the new layout
old_div = """    <div style="margin-top: 20px; display: flex; flex-wrap: wrap; gap: 10px; background: #f2f2f2; padding: 15px; border: 1px solid #ddd;">
        <div style="width: 100%;"><strong>CTRL menu:</strong></div>
        <a href="#" class="btn" style="background: #17a2b8;">Hot.príjem/výdaj</a>
        <a href="#" class="btn" style="background: #17a2b8;" onclick="alert('pPDkod otvára detail rozúčtovania na formulári - implementované priamo v Editácií záznamu.')">Kódy operácií</a>
        <a href="<?= site_url('cashbook') ?>?year=<?= esc($year) ?>&filter=bez_kodu" class="btn" style="background: #17a2b8;" title="pVyd_Bez_Kod">Bez kódu</a>
        <a href="<?= site_url('cashbook') ?>" class="btn" style="background: #17a2b8;" title="pAktualDatum">Dnešný dátum</a>
        <a href="#" class="btn" style="background: #17a2b8;" onclick="window.print()">Tlač</a>

        <div style="width: 100%; margin-top: 10px;"><strong>ALT menu:</strong></div>
        <a href="#" class="btn" style="background: #6c757d;" onclick="alert('Upratovanie je servisná FAND procedúra, v CI4 nie je nutná.')">Upratovanie</a>
        <a href="#" class="btn" style="background: #6c757d;" onclick="alert('1 typ dokladov vyžaduje výber konkrétneho dokladu z gridu (implementované na pozadí pPD_Doklad)')">1 typ dokladov</a>
        <a href="#" class="btn" style="background: #6c757d;">Banka</a>
        <a href="<?= site_url('cashbook/statistics') ?>?year=<?= esc($year) ?>" class="btn" style="background: #6c757d;" title="pStatist">Štatistika</a>
        <a href="<?= site_url('cashbook/summary') ?>?year=<?= esc($year) ?>" class="btn" style="background: #6c757d;" title="pPDsuma">Sumár po akt. pol.</a>
    </div>"""

new_div = """    <div style="margin-top: 20px; display: flex; flex-wrap: wrap; gap: 10px; background: #f2f2f2; padding: 15px; border: 1px solid #ddd;">
        <a href="#" class="btn" style="background: #17a2b8;">Hot.príjem/výdaj</a>
        <a href="#" class="btn" style="background: #17a2b8;" onclick="alert('pPDkod otvára detail rozúčtovania na formulári - implementované priamo v Editácií záznamu.')">Kódy operácií</a>
        <a href="<?= site_url('cashbook') ?>?year=<?= esc($year) ?>&filter=bez_kodu" class="btn" style="background: #17a2b8;" title="pVyd_Bez_Kod">Bez kódu</a>
        <a href="<?= site_url('cashbook') ?>" class="btn" style="background: #17a2b8;" title="pAktualDatum">Dnešný dátum</a>
        <a href="#" class="btn" style="background: #17a2b8;" onclick="window.print()">Tlač</a>
        <a href="#" class="btn" style="background: #17a2b8;" onclick="alert('Upratovanie je servisná FAND procedúra, v CI4 nie je nutná.')">Upratovanie</a>
        <a href="#" class="btn" style="background: #17a2b8;" onclick="alert('1 typ dokladov vyžaduje výber konkrétneho dokladu z gridu (implementované na pozadí pPD_Doklad)')">1 typ dokladov</a>
        <a href="#" class="btn" style="background: #17a2b8;">Banka</a>
        <a href="<?= site_url('cashbook/statistics') ?>?year=<?= esc($year) ?>" class="btn" style="background: #17a2b8;" title="pStatist">Štatistika</a>
        <a href="<?= site_url('cashbook/summary') ?>?year=<?= esc($year) ?>" class="btn" style="background: #17a2b8;" title="pPDsuma">Sumár po akt. pol.</a>
    </div>"""

content = content.replace(old_div, new_div)

with open("ci4_app/app/Views/cashbook/index.php", "w") as f:
    f.write(content)
