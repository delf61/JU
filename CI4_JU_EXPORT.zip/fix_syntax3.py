with open("ci4_app/app/Services/CashbookService.php", "r") as f:
    content = f.read()

content = content.replace("        foreach ($scs as $sc) {\n            $sc_spolu += (float)($sc['spolu'] ?? 0);\n                $summary['sc_spolu'] = $sc_spolu;", "        foreach ($scs as $sc) {\n            $sc_spolu += (float)($sc['spolu'] ?? 0);\n        }\n        $summary['sc_spolu'] = $sc_spolu;")

with open("ci4_app/app/Services/CashbookService.php", "w") as f:
    f.write(content)
