import re

with open("ci4_app/app/Services/CashbookService.php", "r") as f:
    content = f.read()

new_logic = r"""    public function calculateDetailedSummary($year, $upToB = null)
    {
        $entries = $this->getEntries($year);
        $db = \Config\Database::connect();
        
        $summary = [
            'P1' => 0, 'P2' => 0,
            'a1_priebezen' => 0, 'a1_ine' => 0, 'a1_celkove' => 0,
            'a2_priebezen' => 0, 'a2_ine' => 0, 'a2_celkove' => 0,
            'a3_priebezen' => 0, 'a3_ine' => 0, 'a3_celkove' => 0,
            'a4_priebezen' => 0, 'a4_ine' => 0, 'a4_celkove' => 0,
            'hot_prijem' => 0, 'hot_vydaj' => 0, 'ucet_prijem' => 0, 'ucet_vydaj' => 0,
            
            'phm_sc' => 0, 'os_ucet' => 0, 'dan_z_pr' => 0, 'dph' => 0, 'nak_hanim' => 0,
            'zdan_prijmy' => 0, 'dochodok' => 0, 'dopdochspor' => 0,
            'ine_vydaje' => 0, 'vseob' => 0, 'banka' => 0, 'rezia' => 0,
            'leasing' => 0, 'poistne' => 0, 'tovar' => 0, 'odpisy' => 0, 'd_han_m' => 0, 'vyk_prac' => 0,
            
            'akt_pol_p' => 0, 'akt_pol_i' => 0, 'akt_pol_c' => 0,
            'akt_pol_hotovost_ucet' => ''
        ];
        
        // --- 1. Inicializacne stavy ---
        $pocstav_row = clone $db;
        $pocstav_row = $pocstav_row->table('pocstav')->where('YEAR(a)', $year)->get()->getRowArray();
        if ($pocstav_row) {
            $summary['P1'] = (float)$pocstav_row['ph'];
            $summary['P2'] = (float)$pocstav_row['pu'];
        }
        
        // --- 2. Iteracia Cashbook poloziek ---
        foreach ($entries as $entry) {
            if (isset($entry['_fand_deleted']) && $entry['_fand_deleted']) continue;
            
            $r = !empty($entry['r']); 
            $p = !empty($entry['p']); 
            
            $a1 = (float)($entry['a1'] ?? 0);
            $a2 = (float)($entry['a2'] ?? 0);
            $a3 = (float)($entry['a3'] ?? 0);
            $a4 = (float)($entry['a4'] ?? 0);
            $vydaj = $entry['vydaj'] ?? '';
            
            if ($p) {
                $summary['a1_priebezen'] += $a1; $summary['a2_priebezen'] += $a2;
                $summary['a3_priebezen'] += $a3; $summary['a4_priebezen'] += $a4;
            } elseif ($r) {
                $summary['a1_celkove'] += $a1; $summary['a2_celkove'] += $a2;
                $summary['a3_celkove'] += $a3; $summary['a4_celkove'] += $a4;
                $summary['hot_prijem'] += $a1; $summary['hot_vydaj'] += $a2;
                $summary['ucet_prijem'] += $a3; $summary['ucet_vydaj'] += $a4;
            } else {
                $summary['a1_ine'] += $a1; $summary['a2_ine'] += $a2;
                $summary['a3_ine'] += $a3; $summary['a4_ine'] += $a4;
            }
            
            $a13 = $a1 + $a3;
            $a24 = $a2 + $a4;
            
            if ($vydaj === 'h') $summary['phm_sc'] += $a24;
            elseif ($vydaj === '3') $summary['os_ucet'] += $a24;
            elseif ($vydaj === '8') $summary['dan_z_pr'] += $a24;
            elseif ($vydaj === 'd') $summary['dph'] += $a24;
            elseif ($vydaj === '6') $summary['nak_hanim'] += $a24;
            elseif ($vydaj === '1' || $vydaj === '2' || $vydaj === '7') $summary['rezia'] += $a24;
            elseif ($vydaj === 'u') $summary['banka'] += $a24;
            elseif ($vydaj === '4') $summary['poistne'] += $a24;
            elseif ($vydaj === 't') $summary['tovar'] += $a24;
            elseif ($vydaj === '5') $summary['d_han_m'] += $a24;
            elseif ($vydaj === 'a') $summary['vyk_prac'] += $a24;
            
            if (empty($vydaj) && $a24 > 0) $summary['ine_vydaje'] += $a24; 
            
            if ($a13 > 0) {
                if ($vydaj === 'D') $summary['dochodok'] += $a13;
                else $summary['zdan_prijmy'] += $a13;
            }
            
            if ($upToB && $entry['b'] === $upToB) {
                $summary['akt_pol_p'] = $p ? ($a1 + $a2 + $a3 + $a4) : 0;
                $summary['akt_pol_i'] = (!$p && !$r) ? ($a1 + $a2 + $a3 + $a4) : 0;
                $summary['akt_pol_c'] = $r ? ($a1 + $a2 + $a3 + $a4) : 0;
                $summary['akt_pol_hotovost_ucet'] = ($a1 > 0 || $a2 > 0) ? 'Hotovosť' : (($a3 > 0 || $a4 > 0) ? 'Účet' : '');
            }
        }
        
        // --- 3. Zapocitanie Odpisov IKzp ---
        $ikzps = $db->table('ikzp')
            ->where('ro <=', $year) // odpisy the year matches or is less and vo > 0... actually let's match exact year if stored this way
            ->get()->getResultArray();
        
        foreach ($ikzps as $ikzp) {
            // Predpoklad: field vo je casto rocny odpis. FAND logic: if vo>0 then SumaPD.odpisy += vo
            $summary['odpisy'] += (float)($ikzp['vo'] ?? 0);
        }

        // --- 4. Zapocitanie sluzobnych ciest SC ---
        // forall i in SC (koniec<=PD[PARAM.cislo].A) % do SumaPD[1].a123 += SC[i].spolu;
        // The original logic puts SC in 'a123', we can add it to phm_sc or just track it if it differs
        // SC is a separate calculation in the UI we showed it empty, let's actually pull it
        $scs = $db->table('sc')
             ->where('YEAR(zaciatok)', $year)
             ->get()->getResultArray();
             
        $sc_spolu = 0;
        foreach ($scs as $sc) {
            $sc_spolu += (float)($sc['spolu'] ?? 0);
        }
        // FAND logic sometimes displays SC separately or merges it into PHM/Rezia. 
        // We'll calculate it to be precise.
        
        $summary['vseob'] = $summary['rezia'];
        $summary['odpoc_vyd'] = $summary['rezia'] + $summary['leasing'] + $summary['poistne'] + $summary['tovar'] + $summary['odpisy'] + $summary['d_han_m'] + $summary['vyk_prac'];
        $summary['zaklad_pre_vyp'] = $summary['zdan_prijmy'] - $summary['odpoc_vyd'];
        
        return $summary;
    }
}"""

# Using explicit string replacement to avoid regex backslash issues
start_marker = "public function calculateDetailedSummary($year, $upToB = null)"
end_marker = "\n}"
start_idx = content.find(start_marker)

if start_idx != -1:
    brace_count = 0
    in_function = False
    end_idx = -1
    for i in range(start_idx, len(content)):
        if content[i] == '{':
            brace_count += 1
            in_function = True
        elif content[i] == '}':
            brace_count -= 1
            if in_function and brace_count == 0:
                end_idx = i + 1
                break
                
    if end_idx != -1:
        content = content[:start_idx] + new_logic + content[end_idx+1:]
        
with open("ci4_app/app/Services/CashbookService.php", "w") as f:
    f.write(content)
