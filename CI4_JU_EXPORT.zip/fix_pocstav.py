import re

with open("ci4_app/app/Services/CashbookService.php", "r") as f:
    content = f.read()

content = content.replace("->where('rok', $year)", "->where('YEAR(a)', $year)")

with open("ci4_app/app/Services/CashbookService.php", "w") as f:
    f.write(content)
