import re

with open("PRINTER.TXT", "rb") as f:
    lines = f.readlines()

for i in range(1510, 1545):
    try:
        print(lines[i].decode('cp1250', errors='ignore').strip())
    except:
        pass
