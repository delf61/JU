import re

# We will modify ci4_app/app/Views/cashbook/index.php.

# The requested columns are:
# a
# AkyDen
# d40 (which usually maps to 'd' or 'c' in FAND PD table, we'll map to 'd' as it's the text description)
# Celkove
# sDPH
# typ_vyd (usually maps to kodop or a derived field, we'll use kodop if available or vydaj)
# Vydaj (maps to 'vydaj' column)
# ok
# + akcie

with open("ci4_app/app/Views/cashbook/index.php", "r") as f:
    content = f.read()
    
# We need to map Slovak day names
day_names_php = """
<?php 
$days = [
    1 => 'Po', 2 => 'Ut', 3 => 'St', 
    4 => 'Št', 5 => 'Pi', 6 => 'So', 7 => 'Ne'
];
?>
"""

new_headers = """            <tr>
                <th>a</th>
                <th>AkyDen</th>
                <th>d40</th>
                <th class="text-right">Celkove</th>
                <th class="text-right">sDPH</th>
                <th>typ_vyd</th>
                <th>Vydaj</th>
                <th>ok</th>
                <th>Akcie</th>
            </tr>"""

content = re.sub(
    r"            <tr>\n                <th>Dátum \(a\).*?<th>Akcie</th>\n            </tr>",
    new_headers,
    content,
    flags=re.DOTALL
)

new_body = """                    <?php
                        $dayOfWeek = date('N', strtotime($row['a']));
                        $days = [1 => 'Po', 2 => 'Ut', 3 => 'St', 4 => 'Št', 5 => 'Pi', 6 => 'So', 7 => 'Ne'];
                        $akyDen = $days[$dayOfWeek] ?? '';
                        $celkove = ($row['a1'] ?? 0) + ($row['a3'] ?? 0) - ($row['a2'] ?? 0) - ($row['a4'] ?? 0);
                        // V FAND je 'Celkove' obvykle absolútna hodnota pohybu (a1+a3+a2+a4) alebo podla typu.
                        // Použijeme sumu a1+a2+a3+a4, kedze ide o dennik, hodnota je bud prijem alebo vydaj.
                        $celkove = ($row['a1'] ?? 0) + ($row['a2'] ?? 0) + ($row['a3'] ?? 0) + ($row['a4'] ?? 0);
                    ?>
                    <tr>
                        <td><?= esc(date('d.m.Y', strtotime($row['a']))) ?></td>
                        <td><?= esc($akyDen) ?></td>
                        <td><?= esc($row['d'] ?? '') ?></td>
                        <td class="text-right"><?= number_format($celkove, 2, '.', '') ?></td>
                        <td class="text-right"><?= number_format($row['dph'] ?? 0, 2, '.', '') ?></td>
                        <td><?= esc($row['kodop'] ?? '') ?></td>
                        <td><?= esc($row['vydaj'] ?? '') ?></td>
                        <td><?= esc($row['r'] ? 'Áno' : '') ?></td>
                        <td>
                            <a href="<?= site_url('cashbook/edit/' . esc($row['b']) . '/' . esc($year)) ?>" class="btn btn-edit">Editovať</a>
                            <form action="<?= site_url('cashbook/delete/' . esc($row['b']) . '/' . esc($year)) ?>" method="post" style="display:inline;" onsubmit="return confirm('Naozaj vymazať tento záznam?');">
                                <button type="submit" class="btn btn-danger" style="background:#dc3545;color:white;border:none;padding:5px 10px;border-radius:3px;cursor:pointer;">Vymazať</button>
                            </form>
                        </td>
                    </tr>"""
                    
content = re.sub(
    r"                    <tr>\n                        <td><\?= esc\(date\('d\.m\.Y', strtotime\(\$row\['a'\]\)\)\) \?></td>.*?</tr>",
    new_body,
    content,
    flags=re.DOTALL
)

with open("ci4_app/app/Views/cashbook/index.php", "w") as f:
    f.write(content)

