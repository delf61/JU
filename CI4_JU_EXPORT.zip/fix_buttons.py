import re

with open("ci4_app/app/Views/cashbook/index.php", "r") as f:
    content = f.read()

# Replace the text inside the buttons
replacements = {
    '>Shift+F1/F2 Hot.príjem/výdaj</a>': '>Hot.príjem/výdaj</a>',
    '>Ctrl+F6 Kódy operácií</a>': '>Kódy operácií</a>',
    '>Ctrl+F7 Bez kódu</a>': '>Bez kódu</a>',
    '>Ctrl+F8 Dnešný dátum</a>': '>Dnešný dátum</a>',
    '>Ctrl+F9/F10 Tlač</a>': '>Tlač</a>',
    '>Alt+F1 Upratovanie</a>': '>Upratovanie</a>',
    '>Alt+F2 1 typ dokladov</a>': '>1 typ dokladov</a>',
    '>Alt+F3 Banka</a>': '>Banka</a>',
    '>Alt+F4 Štatistika</a>': '>Štatistika</a>',
    '>Alt+F5 Sumár po akt. pol.</a>': '>Sumár po akt. pol.</a>',
}

for old, new in replacements.items():
    content = content.replace(old, new)

with open("ci4_app/app/Views/cashbook/index.php", "w") as f:
    f.write(content)
