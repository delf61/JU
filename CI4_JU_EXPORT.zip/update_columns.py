import re

with open("ci4_app/app/Views/cashbook/index.php", "r") as f:
    content = f.read()

# Update table headers
new_headers = """            <tr>
                <th>a</th>
                <th>AkyDen</th>
                <th>d40</th>
                <th class="text-right">Celkove</th>
                <th class="text-right">sDPH</th>
                <th>typ_vyd</th>
                <th>Vydaj</th>
                <th>ok</th>
                <th>Akcie</th>
            </tr>"""
content = re.sub(
    r"            <tr>\n                <th>Dátum \(a\).*?<th>Akcie</th>\n            </tr>",
    new_headers,
    content,
    flags=re.DOTALL
)

# Update table body
new_body = """                    <tr>
                        <td><?= esc(date('d.m.Y', strtotime($row['a']))) ?></td>
                        <td><?= esc(date('l', strtotime($row['a']))) ?></td>
                        <td><?= esc($row['d']) ?></td>
                        <td class="text-right"><?= number_format(($row['a1'] ?? 0) + ($row['a3'] ?? 0) - ($row['a2'] ?? 0) - ($row['a4'] ?? 0), 2, '.', '') ?></td>
                        <td class="text-right"><?= number_format(($row['dph'] ?? 0), 2, '.', '') ?></td>
                        <td><?= esc($row['vydaj']) ?></td>
                        <td><?= esc($row['vydaj']) ?></td>
                        <td>OK</td>
                        <td>"""
# Let's see what row looks like exactly first.
