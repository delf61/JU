with open("ci4_app/app/Services/CashbookService.php", "r") as f:
    content = f.read()
    
# Chcem overit, ci v calculateDetailedSummary len vratim hardcodovane sumy
lines = content.split('\n')
for i, line in enumerate(lines):
    if "public function calculateDetailedSummary" in line:
        for j in range(i, i+150):
            if j < len(lines):
                print(lines[j])
        break
