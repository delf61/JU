import re

with open("PRINTER.TXT", "rb") as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    try:
        decoded = line.decode('cp1250', errors='ignore')
        if 'sDPH' in decoded or 'celkove' in decoded.lower():
            start = max(0, i - 10)
            end = min(len(lines), i + 20)
            print(f"--- Context around line {i} ---")
            for j in range(start, end):
                print(lines[j].decode('cp1250', errors='ignore').strip())
            print("\n")
            break
    except:
        pass
