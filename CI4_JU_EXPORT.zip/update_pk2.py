with open("ci4_app/app/Models/PdModel.php", "r") as f:
    content = f.read()

content = content.replace("protected $primaryKey = 'b';", "protected $primaryKey = 'PK';")
content = content.replace("protected $useAutoIncrement = false;", "protected $useAutoIncrement = true;")

content = content.replace("'a',", "'PK',\n        'a',")

with open("ci4_app/app/Models/PdModel.php", "w") as f:
    f.write(content)
