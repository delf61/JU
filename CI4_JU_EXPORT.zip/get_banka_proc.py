import re

def extract_section(keyword, lines):
    in_section = False
    section_lines = []
    for line in lines:
        try:
            decoded = line.decode('cp1250', errors='ignore')
            if keyword in decoded:
                in_section = True
            
            if in_section:
                section_lines.append(decoded.strip())
                if 'end;' in decoded and len(section_lines) > 5 and not 'begin' in decoded.split('end;')[1]: 
                    pass
                if len(section_lines) > 100:
                    break
                if ' ' in decoded and len(section_lines) > 2 and keyword not in decoded:
                    break
        except:
            pass
    return section_lines

with open("PRINTER.TXT", "rb") as f:
    lines = f.readlines()

print("=== pPD_banka ===")
for l in extract_section('pPD_banka', lines):
    print(l)

