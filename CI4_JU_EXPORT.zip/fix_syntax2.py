with open("ci4_app/app/Services/CashbookService.php", "r") as f:
    content = f.read()

if not content.strip().endswith("}"):
    content += "\n}\n"

with open("ci4_app/app/Services/CashbookService.php", "w") as f:
    f.write(content)
