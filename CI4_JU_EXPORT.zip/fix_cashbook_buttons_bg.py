with open("ci4_app/app/Views/cashbook/index.php", "r") as f:
    content = f.read()

# Replace hardcoded light background colors with CSS variables or specific classes.
# <div style="margin-top: 20px; display: flex; flex-wrap: wrap; gap: 10px; background: #f2f2f2; padding: 15px; border: 1px solid #ddd;">
old_div = '<div style="margin-top: 20px; display: flex; flex-wrap: wrap; gap: 10px; background: #f2f2f2; padding: 15px; border: 1px solid #ddd;">'
new_div = '<div class="card" style="margin-top: 20px; display: flex; flex-wrap: wrap; gap: 10px; padding: 15px; border: 1px solid var(--border-color); background-color: var(--card-bg);">'

content = content.replace(old_div, new_div)

with open("ci4_app/app/Views/cashbook/index.php", "w") as f:
    f.write(content)

