import re

with open("ci4_app/app/Views/cashbook/index.php", "r") as f:
    content = f.read()

# Oprava odkazu Banka
content = content.replace(
    '<a href="<?= site_url(\'cashbook\') ?>?year=<?= esc($year) ?>&filter=banka" class="btn" style="background: #17a2b8;" title="pPD_banka">Banka</a>',
    '<a href="<?= site_url(\'bank\') ?>?year=<?= esc($year) ?>" class="btn" style="background: #17a2b8;" title="Otvoriť bankové výpisy (Ucet)">Banka</a>'
)

# A odstranenie stareho podmieneneho nadpisu
content = content.replace(
    "<h1><?= (isset($_GET['filter']) && $_GET['filter'] === 'banka') ? 'Peňažný denník - Banka' : 'Peňažný denník (Cashbook)' ?></h1>",
    "<h1>Peňažný denník (Cashbook)</h1>"
)

with open("ci4_app/app/Views/cashbook/index.php", "w") as f:
    f.write(content)

