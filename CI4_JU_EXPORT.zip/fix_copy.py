import re

with open("ci4_app/app/Controllers/BankStatementController.php", "r") as f:
    content = f.read()

new_logic = """    public function uiCopy($b, $date)
    {
        $db = \\Config\\Database::connect();
        $record = $db->table('ucet')->where('b', hex2bin($b))->where('d', hex2bin($date))->get()->getRowArray();
        
        if ($record) {
            // Pouzivatel chce cistu kopiu 1:1. Ak sa vyskytne nejaky interny auto-increment primarny kluc (napr id), 
            // musim ho zmazat z pola zaznamu aby ho DB vygenerovala nanovo. Tabulka zvycajne v MariaDB ma `id`.
            if (isset($record['id'])) {
                unset($record['id']);
            }
            if (isset($record['_id'])) {
                unset($record['_id']);
            }
            
            try {
                $db->table('ucet')->insert($record);
                return redirect()->back()->with('success', 'Záznam bol úspešne skopírovaný 1:1.');
            } catch (\\Exception $e) {
                return redirect()->back()->with('error', 'Chyba pri kopírovaní: ' . $e->getMessage());
            }
        }
        
        return redirect()->back()->with('error', 'Záznam pre kópiu nebol nájdený.');
    }"""

start_idx = content.find('public function uiCopy($b, $date)')
if start_idx != -1:
    end_idx = content.find('return redirect()->back()->with(\'error\', \'Záznam pre kópiu nebol nájdený.\');\n    }', start_idx)
    end_idx += len('return redirect()->back()->with(\'error\', \'Záznam pre kópiu nebol nájdený.\');\n    }')
    content = content[:start_idx] + new_logic.strip() + content[end_idx:]

with open("ci4_app/app/Controllers/BankStatementController.php", "w") as f:
    f.write(content)
