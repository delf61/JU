import re

with open("PRINTER.TXT", "rb") as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    try:
        decoded = line.decode('cp1250', errors='ignore')
        if 'a5 :=' in decoded or 'a6 :=' in decoded:
            print(f"Line {i}: {decoded.strip()}")
    except:
        pass
