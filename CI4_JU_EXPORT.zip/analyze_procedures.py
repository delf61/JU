import re

def extract_proc(proc_name, lines):
    in_proc = False
    proc_lines = []
    for line in lines:
        try:
            decoded = line.decode('cp1250', errors='ignore')
            if f' {proc_name} ' in decoded or f' {proc_name}(' in decoded or f' {proc_name}' in decoded:
                if ' P ' in decoded: # start of procedure
                    in_proc = True
            
            if in_proc:
                proc_lines.append(decoded.strip())
                if 'end;' in decoded and len(proc_lines) > 5 and proc_lines[-1] == 'end;':
                     pass
                if ' P ' in decoded and len(proc_lines) > 2:
                    break
        except:
            pass
    return proc_lines

with open("PRINTER.TXT", "rb") as f:
    lines = f.readlines()

for proc in ['pPDkod', 'pVyd_Bez_Kod', 'pAktualDatum', 'pPD_Doklad', 'pStatist', 'pPDsuma']:
    res = extract_proc(proc, lines)
    print(f"=== {proc} ===")
    for l in res[:20]:
        print(l)
    print("...\n")

