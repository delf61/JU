import re

with open("ci4_app/app/Config/Routes.php", "r") as f:
    content = f.read()

new_routes = """
// Cashbook Legacy Procedures
$routes->get('cashbook/statistics', 'CashbookController::statistics');
$routes->get('cashbook/summary', 'CashbookController::summary');
$routes->get('cashbook/document/(:any)/(:num)', 'CashbookController::documentRedirect/$1/$2');

$routes->group('cashbook', function($routes) {
"""
content = content.replace("$routes->group('cashbook', function($routes) {", new_routes)

with open("ci4_app/app/Config/Routes.php", "w") as f:
    f.write(content)
