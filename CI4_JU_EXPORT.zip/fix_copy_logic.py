with open("ci4_app/app/Controllers/BankStatementController.php", "r") as f:
    content = f.read()

new_logic = """    public function uiCopy($b, $date)
    {
        // Basic copy logic
        $db = \\Config\\Database::connect();
        $record = $db->table('ucet')->where('b', hex2bin($b))->where('d', hex2bin($date))->get()->getRowArray();
        
        if ($record) {
            $orig_b = trim($record['b']);
            if (strlen($orig_b) < 6) {
                $record['b'] = $orig_b . '_C';
            } else {
                $record['b'] = substr($orig_b, 0, 6) . '_C';
            }
            
            try {
                $db->table('ucet')->insert($record);
                return redirect()->back()->with('success', 'Záznam bol úspešne skopírovaný.');
            } catch (\\Exception $e) {
                return redirect()->back()->with('error', 'Chyba pri kopírovaní: ' . $e->getMessage());
            }
        }
        
        return redirect()->back()->with('error', 'Záznam pre kópiu nebol nájdený.');
    }"""

# Extract the old function
start_idx = content.find('public function uiCopy($b, $date)')
if start_idx != -1:
    end_idx = content.find('return redirect()->back()->with(\'error\', \'Záznam pre kópiu nebol nájdený.\');\n    }', start_idx)
    end_idx += len('return redirect()->back()->with(\'error\', \'Záznam pre kópiu nebol nájdený.\');\n    }')
    content = content[:start_idx] + new_logic.strip() + content[end_idx:]

with open("ci4_app/app/Controllers/BankStatementController.php", "w") as f:
    f.write(content)
