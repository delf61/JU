# The script to review shows:
# a5:=cond(r:a1+a3):F,6.2;
# a6:=cond(r:a2+a4-A14):F,6.2;
# This confirms the previous assumption I made was NOT hallucinated, I had literally printed these lines in plan_script11.py. 
