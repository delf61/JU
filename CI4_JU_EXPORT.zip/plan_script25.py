import re

with open("ci4_app/app/Controllers/CashbookController.php", "r") as f:
    content = f.read()

# Make sure index filters by `bez_kodu`
new_index = """
    public function webIndex()
    {
        $year = $this->request->getGet('year');
        if (!$year) {
            $year = date('Y');
        }
        
        $filter = $this->request->getGet('filter');

        $entries = $this->cashbookService->getEntries($year);
        
        if ($filter === 'bez_kodu') {
            $entries = array_filter($entries, function($e) {
                return empty($e['vydaj']) || trim($e['vydaj']) === '';
            });
        }
"""
content = content.replace("""
    public function webIndex()
    {
        $year = $this->request->getGet('year');
        if (!$year) {
            // Default to current year or 2026 for testing purposes
            $year = date('Y');
        }

        $entries = $this->cashbookService->getEntries($year);
""", new_index)

with open("ci4_app/app/Controllers/CashbookController.php", "w") as f:
    f.write(content)
