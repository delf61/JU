import re

with open("ci4_app/app/Views/bank/index.php", "r") as f:
    view_content = f.read()

view_update = """                    <?php 
                        $enc_b = bin2hex($row['b']);
                        $enc_d = bin2hex($row['d']);
                        $enc_ua = bin2hex($row['ua']);
                        $enc_pa = bin2hex((string)$row['pa']);
                    ?>
                    <a href="<?= site_url("bank/edit/$enc_b/$enc_d/$enc_ua/$enc_pa") ?>" class="btn-action" style="background:#ffc107; color:#000;">Editovať</a>
                    
                    <form action="<?= site_url("bank/copy/$enc_b/$enc_d/$enc_ua/$enc_pa") ?>" method="post" style="display:inline;">
                        <button type="submit" class="btn-action" style="background:#17a2b8; color:#fff; border:none; cursor:pointer;" >Kópia</button>
                    </form>

                    <form action="<?= site_url("bank/delete/$enc_b/$enc_d/$enc_ua/$enc_pa") ?>" method="post" style="display:inline;">
                        <button type="submit" class="btn-action" style="background:#dc3545; color:#fff; border:none; cursor:pointer;" onclick="return confirm('Naozaj vymazať tento záznam?');">Vymazať</button>
                    </form>"""

# Find the start and end of the block to replace
start = view_content.find("                    <?php \n                        $enc_b = bin2hex($row['b']);")
end = view_content.find("                    </form>\n                </td>", start)

if start != -1 and end != -1:
    view_content = view_content[:start] + view_update + view_content[end:]

with open("ci4_app/app/Views/bank/index.php", "w") as f:
    f.write(view_content)


with open("ci4_app/app/Config/Routes.php", "r") as f:
    routes = f.read()

routes = routes.replace("bank/edit/(:any)/(:any)'", "bank/edit/(:any)/(:any)/(:any)/(:any)'")
routes = routes.replace("bank/delete/(:any)/(:any)'", "bank/delete/(:any)/(:any)/(:any)/(:any)'")
routes = routes.replace("bank/copy/(:any)/(:any)'", "bank/copy/(:any)/(:any)/(:any)/(:any)'")

with open("ci4_app/app/Config/Routes.php", "w") as f:
    f.write(routes)


with open("ci4_app/app/Controllers/BankStatementController.php", "r") as f:
    controller_content = f.read()

controller_content = controller_content.replace(
    "public function uiEdit($b, $date)", 
    "public function uiEdit($b, $date, $ua, $pa)"
)
controller_content = controller_content.replace(
    "public function uiDelete($b, $date)", 
    "public function uiDelete($b, $date, $ua, $pa)"
)

new_copy = """    public function uiCopy($b, $date, $ua, $pa)
    {
        $db = \\Config\\Database::connect();
        $record = $db->table('ucet')
            ->where('b', hex2bin($b))
            ->where('d', hex2bin($date))
            ->where('ua', hex2bin($ua))
            ->where('pa', hex2bin($pa))
            ->get()->getRowArray();
        
        if ($record) {
            // Pouzivatel chce cistu kopiu 1:1. Ak sa vyskytne nejaky interny auto-increment primarny kluc (napr id), 
            // musim ho zmazat z pola zaznamu aby ho DB vygenerovala nanovo.
            if (isset($record['id'])) {
                unset($record['id']);
            }
            if (isset($record['_id'])) {
                unset($record['_id']);
            }
            
            try {
                $db->table('ucet')->insert($record);
                return redirect()->back()->with('success', 'Záznam bol úspešne skopírovaný 1:1.');
            } catch (\\Exception $e) {
                return redirect()->back()->with('error', 'Chyba pri kopírovaní: ' . $e->getMessage());
            }
        }
        
        return redirect()->back()->with('error', 'Záznam pre kópiu nebol nájdený.');
    }"""

# Nahradiť public function uiCopy
start_copy = controller_content.find("public function uiCopy($b, $date)")
end_copy = controller_content.find("return redirect()->back()->with('error', 'Záznam pre kópiu nebol nájdený.');\n    }", start_copy)
end_copy += len("return redirect()->back()->with('error', 'Záznam pre kópiu nebol nájdený.');\n    }")

if start_copy != -1:
    controller_content = controller_content[:start_copy] + new_copy.strip() + controller_content[end_copy:]

with open("ci4_app/app/Controllers/BankStatementController.php", "w") as f:
    f.write(controller_content)

