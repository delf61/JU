import re

with open("ci4_app/app/Views/cashbook/index.php", "r") as f:
    content = f.read()

buttons_html = """
    <div style="margin-top: 20px; display: flex; flex-wrap: wrap; gap: 10px; background: #f2f2f2; padding: 15px; border: 1px solid #ddd;">
        <div style="width: 100%;"><strong>CTRL menu:</strong></div>
        <a href="#" class="btn" style="background: #17a2b8;" onclick="alert('Hot.príjem/výdaj (not yet implemented)')">Shift+F1/F2 Hot.príjem/výdaj</a>
        <a href="#" class="btn" style="background: #17a2b8;" onclick="alert('Kódy operácií - pPDkod (not yet implemented)')">Ctrl+F6 Kódy operácií</a>
        <a href="#" class="btn" style="background: #17a2b8;" onclick="alert('Bez kódu - pVyd_Bez_Kod (not yet implemented)')">Ctrl+F7 Bez kódu</a>
        <a href="#" class="btn" style="background: #17a2b8;" onclick="alert('Dnešný dátum - pAktualDatum (not yet implemented)')">Ctrl+F8 Dnešný dátum</a>
        <a href="#" class="btn" style="background: #17a2b8;" onclick="window.print()">Ctrl+F9/F10 Tlač</a>

        <div style="width: 100%; margin-top: 10px;"><strong>ALT menu:</strong></div>
        <a href="#" class="btn" style="background: #6c757d;" onclick="alert('Upratovanie (not yet implemented)')">Alt+F1 Upratovanie</a>
        <a href="#" class="btn" style="background: #6c757d;" onclick="alert('1 typ dokladov - pPD_Doklad (not yet implemented)')">Alt+F2 1 typ dokladov</a>
        <a href="#" class="btn" style="background: #6c757d;" onclick="alert('Banka (not yet implemented)')">Alt+F3 Banka</a>
        <a href="#" class="btn" style="background: #6c757d;" onclick="alert('Štatistika - pStatist (not yet implemented)')">Alt+F4 Štatistika</a>
        <a href="#" class="btn" style="background: #6c757d;" onclick="alert('Sumár po akt. pol. - pPDsuma (not yet implemented)')">Alt+F5 Sumár po akt. pol.</a>
    </div>
"""

# Inject buttons below the table
content = content.replace('</table>', '</table>\n' + buttons_html)

# Change default pagination to 10 rows per page
content = content.replace('pageLength: 25,', 'pageLength: 10,')

with open("ci4_app/app/Views/cashbook/index.php", "w") as f:
    f.write(content)
