with open("ci4_app/app/Services/CashbookService.php", "r") as f:
    content = f.read()

# Nahradenie dvoch zatvaracich zátvoriek na konci jednou
content = content.replace("}}\n", "}\n")

if content.strip().endswith("}}"):
    content = content.rstrip()[:-1] + "\n"

with open("ci4_app/app/Services/CashbookService.php", "w") as f:
    f.write(content)
