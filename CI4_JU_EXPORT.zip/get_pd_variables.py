import re

with open("PRINTER.TXT", "rb") as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    try:
        decoded = line.decode('cp1250', errors='ignore')
        if 'epdbrowse' in decoded.lower():
            start = max(0, i - 50)
            end = min(len(lines), i + 20)
            print(f"--- Context before ePDbrowse at line {i} ---")
            for j in range(start, end):
                print(lines[j].decode('cp1250', errors='ignore').strip())
            print("\n")
            break
    except:
        pass
