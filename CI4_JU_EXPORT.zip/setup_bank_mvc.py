import os
import re

# Model
with open("ci4_app/app/Models/BankStatementModel.php", "w") as f:
    f.write("""<?php
namespace App\Models;

use CodeIgniter\Model;

class BankStatementModel extends Model
{
    protected $table = 'ucet';
    protected $primaryKey = 'b'; 
    protected $useAutoIncrement = false;
    protected $returnType = 'array';
    protected $allowedFields = [
        'a', 'b', 'c', 'd', 'ba', 'cu', 'ua', 'pa', 'qa', 'ra', 'ba1', 'cu1', 'nova', 'vydaj', 'rok'
    ];
}
""")

# Service
with open("ci4_app/app/Services/BankStatementService.php", "w") as f:
    f.write("""<?php
namespace App\Services;

use App\Models\BankStatementModel;

class BankStatementService
{
    protected $model;

    public function __construct()
    {
        $this->model = new BankStatementModel();
    }

    public function getEntries($year = null)
    {
        if ($year) {
            return $this->model->where('YEAR(a)', $year)->findAll();
        }
        return $this->model->findAll();
    }
}
""")

# Controller
with open("ci4_app/app/Controllers/BankStatementController.php", "w") as f:
    f.write("""<?php
namespace App\Controllers;

use App\Services\BankStatementService;
use CodeIgniter\RESTful\ResourceController;

class BankStatementController extends ResourceController
{
    protected $bankService;

    public function __construct()
    {
        $this->bankService = new BankStatementService();
    }

    public function webIndex()
    {
        $year = $this->request->getGet('year');
        if (!$year) {
            $year = date('Y');
        }

        $entries = $this->bankService->getEntries($year);
        
        return view('bank/index', [
            'entries' => $entries,
            'year' => $year
        ]);
    }
}
""")

# View directory
os.makedirs("ci4_app/app/Views/bank", exist_ok=True)

# View File
with open("ci4_app/app/Views/bank/index.php", "w") as f:
    f.write("""<!DOCTYPE html>
<html lang="sk">
<head>
    <meta charset="UTF-8">
    <title>Bankový výpis - DATOVÝ EDITOR</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 20px; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .btn-back { display: inline-block; padding: 8px 15px; background-color: #6c757d; color: #fff; text-decoration: none; border-radius: 4px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 14px; }
        th, td { border: 1px solid #ddd; padding: 8px 12px; text-align: left; }
        th { background-color: #f2f2f2; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
    </style>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <link rel="stylesheet" href="https://cdn.datatables.net/2.1.8/css/dataTables.dataTables.min.css">
    <script src="https://cdn.datatables.net/2.1.8/js/dataTables.min.js"></script>
</head>
<body>
    <div class="header">
        <h1>Bankové výpisy (Ucet) - Rok <?= esc($year) ?></h1>
        <a href="<?= site_url('cashbook') ?>?year=<?= esc($year) ?>" class="btn-back">Späť na Peňažný denník</a>
    </div>

    <table id="bankTable" class="display">
        <thead>
            <tr>
                <th class="text-center">Realizov.<br>dňa</th>
                <th class="text-center">Por.<br>50</th>
                <th>Popis operácie</th>
                <th class="text-right">Čiastka<br>€</th>
                <th class="text-center">C</th>
                <th class="text-center">P</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($entries as $row): ?>
            <tr>
                <td class="text-center"><?= esc(date('d.m.Y', strtotime($row['d']))) ?></td>
                <td class="text-center"><?= esc($row['b']) ?></td>
                <td><?= esc($row['ua']) ?></td>
                <td class="text-right"><?= number_format($row['pa'], 2, '.', '') ?></td>
                <td class="text-center"><?= !empty($row['ra']) ? 'A' : 'N' ?></td>
                <td class="text-center"><?= !empty($row['qa']) ? 'A' : 'N' ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <script>
        $(document).ready(function() {
            $('#bankTable').DataTable({
                language: {
                    search: "Vyhľadávanie:",
                    lengthMenu: "Zobraziť _MENU_ záznamov na stranu",
                    zeroRecords: "Žiadne záznamy",
                    info: "Zobrazených _START_ až _END_ z _TOTAL_ záznamov",
                    paginate: {
                        first: "Prvá", previous: "Predchádzajúca", next: "Ďalšia", last: "Posledná"
                    }
                },
                pageLength: 10
            });
        });
    </script>
</body>
</html>
""")

# Routes
with open("ci4_app/app/Config/Routes.php", "r") as f:
    routes = f.read()

routes = routes.replace("// Cashbook Legacy Procedures", "// Bank Statement\n$routes->get('bank', 'BankStatementController::webIndex');\n\n// Cashbook Legacy Procedures")

with open("ci4_app/app/Config/Routes.php", "w") as f:
    f.write(routes)

# Update Link in Cashbook
with open("ci4_app/app/Views/cashbook/index.php", "r") as f:
    cb_view = f.read()

cb_view = cb_view.replace('<a href="#" class="btn" style="background: #17a2b8;">Banka</a>', '<a href="<?= site_url(\'bank\') ?>?year=<?= esc($year) ?>" class="btn" style="background: #17a2b8;">Banka</a>')

with open("ci4_app/app/Views/cashbook/index.php", "w") as f:
    f.write(cb_view)

