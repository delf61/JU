import re

def extract_section(keyword, lines, exact=False):
    in_section = False
    section_lines = []
    for line in lines:
        try:
            decoded = line.decode('cp1250', errors='ignore')
            if exact:
                if decoded.strip() == keyword or decoded.strip().startswith(keyword):
                    in_section = True
            else:
                if keyword in decoded:
                    in_section = True
            
            if in_section:
                section_lines.append(decoded.strip())
                if len(section_lines) > 200: # Limit size
                    break
                if 'end;' in decoded and len(section_lines) > 10 and not exact:
                    pass
                if len(section_lines) > 5 and ' ' in decoded and not keyword in decoded:
                    break
        except:
            pass
    return section_lines

with open("PRINTER.TXT", "rb") as f:
    lines = f.readlines()

print("=== mPDsuma ===")
for l in extract_section(' M  mPDsuma ', lines, True)[:60]:
    print(l)

print("\n=== eSumaPD ===")
for l in extract_section(' E  eSumaPD ', lines, True)[:60]:
    print(l)

print("\n=== SumaPD.x ===")
for l in extract_section('    SumaPD.x ', lines, True)[:60]:
    print(l)
