import re

with open("ci4_app/app/Controllers/CashbookController.php", "r") as f:
    content = f.read()

new_methods = """
    // --- Legacy Migrated Procedures ---

    public function statistics()
    {
        $year = $this->request->getGet('year') ?: date('Y');
        $stats = $this->cashbookService->calculateStatistics($year);
        
        return view('cashbook/statistics', [
            'year' => $year,
            'stats' => $stats
        ]);
    }

    public function summary()
    {
        $year = $this->request->getGet('year') ?: date('Y');
        $b = $this->request->getGet('b');
        
        $summary = $this->cashbookService->calculateDetailedSummary($year, $b);
        
        return view('cashbook/summary', [
            'year' => $year,
            'b' => $b,
            'summary' => $summary
        ]);
    }

    public function documentRedirect($b, $year)
    {
        // Legacy pPD_Doklad logic
        $prefix = substr($b, 0, 2);
        if ($prefix === '40') {
            // SC (Logbook)
            return redirect()->to('trips?year=' . $year);
        } elseif ($prefix === '50') {
            // Invoices?
            return redirect()->to('invoices?year=' . $year);
        }
        
        return redirect()->back()->with('error', 'Neznámy typ dokladu pre presmerovanie.');
    }
}
"""

content = re.sub(r"}\s*$", new_methods, content)

with open("ci4_app/app/Controllers/CashbookController.php", "w") as f:
    f.write(content)
