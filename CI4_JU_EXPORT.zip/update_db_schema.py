import gzip
import re
import os

input_file = "migration_dump/ju_migration.sql.gz"
output_file = "migration_dump/ju_migration.sql_pk.gz"

if not os.path.exists(input_file):
    print("Input file not found!")
    exit(1)

# Patter pre najdenie definicie tabulky: CREATE TABLE `meno` (
create_pattern = re.compile(r'CREATE TABLE `([^`]+)` \(')

out_lines = []

with gzip.open(input_file, "rt", encoding="utf-8") as f:
    in_table = False
    table_name = ""
    
    for line in f:
        # Pre CREATE TABLE
        match = create_pattern.search(line)
        if match:
            in_table = True
            table_name = match.group(1)
            out_lines.append(line)
            # Pridame PK hned ako prvy riadok
            out_lines.append("  `PK` int(6) NOT NULL AUTO_INCREMENT,\n")
            continue
            
        if in_table:
            # Ak narazime na zavretie CREATE TABLE:
            if line.startswith(') ENGINE='):
                # Musime pridat PRIMARY KEY(PK) na koniec pred zatvorkou
                # Lenze MySQL pozaduje ciarku predtym. 
                # Aby sme to nerobili komplikovane, pridame PRIMARY KEY (`PK`) hned za definiciou pola, alebo nakoniec.
                # Predosly riadok moze nemat ciarku, ak nebol primary key.
                
                # Zistime aky bol predosly riadok a pridame mu ciarku ak nema.
                prev = out_lines[-1].rstrip()
                if not prev.endswith(','):
                    out_lines[-1] = prev + ",\n"
                
                out_lines.append("  PRIMARY KEY (`PK`)\n")
                out_lines.append(line)
                in_table = False
                continue
                
            # Ak v existujucej tabulke bola definicia PRIMARY KEY (`nieco`), tak ju prepiseme na obycajny INDEX (KEY) alebo odstranime
            if 'PRIMARY KEY' in line:
                # Nahradime povodny PRIMARY KEY za obycajny KEY, inak by MySQL zhavarovalo (Multiple primary keys)
                line = line.replace('PRIMARY KEY', 'KEY `old_pk`')
                
        # Pre INSERT INTO `tabulka` VALUES ... 
        # Zistime ci je to riadok plny dat. Pretoze inserty idu vacsinou: INSERT INTO `tabulka` VALUES (hodnota, hodnota)
        # Kedze sme pridali AUTO_INCREMENT, mozeme mu poslat len NULL na prve miesto a MySQL mu prideli PK.
        if line.startswith('INSERT INTO `'):
            # Prehladame VALUES (, ak to nie je explicitny insert s menami stlpcov
            if 'VALUES (' in line and not ') VALUES' in line:
                 line = line.replace('VALUES (', 'VALUES (NULL, ')
                 # Pozor, MySQL dump vacsinou robi `INSERT INTO table VALUES (...),(...),(...);`
                 # To znamena ze ( sa tam opakuje milionkrat.
                 # Vyuzijeme Regex na pridanie NULL do kazdej zatvorky.
                 # Riadok vyzera napr: INSERT INTO `a` VALUES (1,2),(3,4);
                 # Treba nahradit kazde '(' (ktore nie je vo vnutri stringu) za '(NULL, '
            elif ') VALUES (' in line:
                 # Ak obsahuje specifikaciu stlpcov (INSERT INTO t (col1, col2) VALUES (x,y)),
                 # musime pridat `PK` do stlpcov a NULL do hodnot. To byva tazke naparsovat jednoducho.
                 pass

        out_lines.append(line)

# Let's verify what happens. Modifying raw SQL dumps string-by-string for INSERTs is dangerous because of string escaping like 'test(value)'.
# A safer way to do this is to load the DB into local MySQL, ALTER tables, and dump it back!
