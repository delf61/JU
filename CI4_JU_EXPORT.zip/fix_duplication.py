import re

with open("ci4_app/app/Views/cashbook/index.php", "r") as f:
    content = f.read()

# Let's remove the duplicated buttons
duplicate_start = content.find('<a href="#" class="btn" style="background: #17a2b8;" onclick="alert(\'Hot.príjem/výdaj (not yet implemented)\')">Shift+F1/F2 Hot.príjem/výdaj</a>')
if duplicate_start != -1:
    # Find the end of the div
    end_of_div = content.find('</div>', duplicate_start)
    if end_of_div != -1:
        content = content[:duplicate_start] + content[end_of_div + 6:]
        
with open("ci4_app/app/Views/cashbook/index.php", "w") as f:
    f.write(content)
