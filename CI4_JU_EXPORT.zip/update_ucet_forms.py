import re

with open("ci4_app/app/Config/Routes.php", "r") as f:
    routes = f.read()

# Change routes to accept generic POST without URL params
routes = routes.replace("$routes->get('bank/edit/(:any)/(:any)/(:any)/(:any)', 'BankStatementController::uiEdit/$1/$2/$3/$4');", "$routes->post('bank/edit', 'BankStatementController::uiEdit');")
routes = routes.replace("$routes->post('bank/delete/(:any)/(:any)/(:any)/(:any)', 'BankStatementController::uiDelete/$1/$2/$3/$4');", "$routes->post('bank/delete', 'BankStatementController::uiDelete');")
routes = routes.replace("$routes->post('bank/copy/(:any)/(:any)/(:any)/(:any)', 'BankStatementController::uiCopy/$1/$2/$3/$4');", "$routes->post('bank/copy', 'BankStatementController::uiCopy');")

with open("ci4_app/app/Config/Routes.php", "w") as f:
    f.write(routes)


with open("ci4_app/app/Views/bank/index.php", "r") as f:
    view = f.read()

# Replace the action buttons with forms containing all row data as hidden inputs
new_actions = r"""                <td class="text-center">
                    <?php 
                        // Encode all fields as hidden inputs to ensure 100% exact matching
                        $hiddenInputs = '';
                        foreach ($row as $key => $val) {
                            $hiddenInputs .= '<input type="hidden" name="'.esc($key).'" value="'.esc($val).'">';
                        }
                    ?>
                    <form action="<?= site_url("bank/edit") ?>" method="post" style="display:inline;">
                        <?= $hiddenInputs ?>
                        <button type="submit" class="btn-action" style="background:#ffc107; color:#000; border:none; cursor:pointer;">Editovať</button>
                    </form>
                    
                    <form action="<?= site_url("bank/copy") ?>" method="post" style="display:inline;">
                        <?= $hiddenInputs ?>
                        <button type="submit" class="btn-action" style="background:#17a2b8; color:#fff; border:none; cursor:pointer;" >Kópia</button>
                    </form>

                    <form action="<?= site_url("bank/delete") ?>" method="post" style="display:inline;">
                        <?= $hiddenInputs ?>
                        <button type="submit" class="btn-action" style="background:#dc3545; color:#fff; border:none; cursor:pointer;" onclick="return confirm('Naozaj vymazať tento záznam?');">Vymazať</button>
                    </form>
                </td>"""

# Find and replace the exact td
start = view.find('<td class="text-center">\n                    <?php \n                        $enc_b = bin2hex($row[\'b\']);')
end = view.find('</td>', start) + 5

if start != -1 and end != -1:
    view = view[:start] + new_actions + view[end:]

with open("ci4_app/app/Views/bank/index.php", "w") as f:
    f.write(view)


with open("ci4_app/app/Controllers/BankStatementController.php", "r") as f:
    ctrl = f.read()

new_ctrl_methods = r"""    public function uiEdit()
    {
        return redirect()->back()->with('error', 'Editácia výpisu nie je zatiaľ implementovaná.');
    }

    public function uiDelete()
    {
        $postData = $this->request->getPost();
        if (empty($postData)) {
            return redirect()->back()->with('error', 'Chýbajú dáta pre vymazanie.');
        }

        $db = \Config\Database::connect();
        $builder = $db->table('ucet');
        
        // Match ALL fields exactly to prevent deleting wrong record
        foreach ($postData as $k => $v) {
            if ($k !== 'id' && $k !== '_id') {
                $builder->where($k, $v);
            }
        }
        
        try {
            $builder->delete();
            return redirect()->back()->with('success', 'Záznam bol úspešne vymazaný.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Chyba pri mazaní: ' . $e->getMessage());
        }
    }

    public function uiCopy()
    {
        $postData = $this->request->getPost();
        if (empty($postData)) {
            return redirect()->back()->with('error', 'Chýbajú dáta pre kópiu.');
        }

        $db = \Config\Database::connect();
        $builder = $db->table('ucet');
        
        // MATCH ALL EXACT FIELDS FROM POST TO ENSURE 100% ACCURACY
        foreach ($postData as $k => $v) {
            if ($k !== 'id' && $k !== '_id') {
                $builder->where($k, $v);
            }
        }
        
        $record = $builder->get()->getRowArray();
        
        if ($record) {
            if (isset($record['id'])) unset($record['id']);
            if (isset($record['_id'])) unset($record['_id']);
            
            try {
                $db->table('ucet')->insert($record);
                return redirect()->back()->with('success', 'Záznam bol úspešne skopírovaný 1:1.');
            } catch (\Exception $e) {
                return redirect()->back()->with('error', 'Chyba pri kopírovaní: ' . $e->getMessage());
            }
        }
        
        return redirect()->back()->with('error', 'Presný záznam pre kópiu nebol nájdený v databáze. Skontrolujte integritu dát.');
    }"""

# Replace the methods
start_methods = ctrl.find('public function uiEdit(')
if start_methods != -1:
    end_methods = ctrl.find('return redirect()->back()->with(\'error\', \'Záznam pre kópiu nebol nájdený.\');\n    }', start_methods)
    if end_methods != -1:
        end_methods += len('return redirect()->back()->with(\'error\', \'Záznam pre kópiu nebol nájdený.\');\n    }')
        ctrl = ctrl[:start_methods] + new_ctrl_methods + ctrl[end_methods:]

with open("ci4_app/app/Controllers/BankStatementController.php", "w") as f:
    f.write(ctrl)
