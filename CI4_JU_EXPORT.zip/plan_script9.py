import re

with open("PRINTER.TXT", "rb") as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    try:
        decoded = line.decode('cp1250', errors='ignore')
        if 'sDPH :=' in decoded or 'Celkove :=' in decoded:
            print(f"Line {i}: {decoded.strip()}")
    except:
        pass
