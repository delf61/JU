import re

with open("ci4_app/app/Controllers/CashbookController.php", "r") as f:
    content = f.read()

# Odstranime zvysny banka filter z CashbookController, lebo to robilo len neplechu a matusi to
banka_filter = """        } elseif ($filter === 'banka') {
            $entries = array_filter($entries, function($e) {
                return ($e['a3'] != 0 || $e['a4'] != 0 || strtolower($e['vydaj'] ?? '') === 'u');
            });
"""

content = content.replace(banka_filter, "")

with open("ci4_app/app/Controllers/CashbookController.php", "w") as f:
    f.write(content)
