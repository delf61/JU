import re

with open("PRINTER.TXT", "rb") as f:
    lines = f.readlines()

in_banka = False
for i, line in enumerate(lines):
    try:
        decoded = line.decode('cp1250', errors='ignore')
        if ' P  pPD_banka' in decoded:
            in_banka = True
        
        if in_banka:
            print(decoded.strip())
            if 'end;' in decoded and i > 100: # heuristic
                # print a bit more just in case
                for j in range(1, 15):
                    print(lines[i+j].decode('cp1250', errors='ignore').strip())
                break
    except:
        pass
