import re

with open("PRINTER.TXT", "rb") as f:
    lines = f.readlines()

def search_text(keyword, context=10):
    print(f"--- Search for {keyword} ---")
    for i, line in enumerate(lines):
        try:
            dec = line.decode('cp1250', errors='ignore')
            if keyword in dec:
                for j in range(max(0, i-2), min(len(lines), i+context)):
                    print(lines[j].decode('cp1250', errors='ignore').strip())
                print("-------------------")
        except:
            pass

search_text('pPDprerus_B')
search_text('eUcet', 20)
search_text('F Ucet', 20)
