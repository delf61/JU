import re

with open("PRINTER.TXT", "rb") as f:
    lines = f.readlines()

def get_block(keyword, length=100):
    for i, line in enumerate(lines):
        try:
            decoded = line.decode('cp1250', errors='ignore')
            if decoded.strip().startswith(keyword):
                return [l.decode('cp1250', errors='ignore').strip() for l in lines[i:i+length]]
        except:
            pass
    return []

print("=== eUcetbrowse ===")
for l in get_block(' E  eUcet', 80):
    print(l)

print("\n=== Ucet Schema ===")
for l in get_block(' F  Ucet', 40):
    print(l)
