import gzip
import re

input_file = "migration_dump/ju_migration.sql.gz"
output_file = "migration_dump/ju_migration.sql_pk.gz"

create_pattern = re.compile(r'CREATE TABLE `([^`]+)` \(')
primary_key_pattern = re.compile(r'^\s*PRIMARY KEY\s*\(`([^`]+)`\)', re.IGNORECASE)

with gzip.open(input_file, "rt", encoding="utf-8") as fin:
    lines = fin.readlines()

out_lines = []
in_table = False
table_name = ""

for line in lines:
    match = create_pattern.search(line)
    if match:
        in_table = True
        table_name = match.group(1)
        out_lines.append(line)
        # Pridame Auto Increment column ako prvy stlpec
        out_lines.append("  `PK` int(6) NOT NULL AUTO_INCREMENT,\n")
        continue

    if in_table:
        # Prepis existujucich PRIMARY KEY
        if 'PRIMARY KEY' in line:
            line = line.replace('PRIMARY KEY', f'KEY `idx_{table_name}_old_pk`')
            
        # Uzavretie tabulky
        if line.startswith(') ENGINE='):
            # Posledny stlpec nad uzatvaracou zatvorkou
            prev = out_lines[-1].rstrip()
            if not prev.endswith(','):
                out_lines[-1] = prev + ",\n"
            
            # Pridame novy PRIMARY KEY na koniec definicie tabulky
            out_lines.append("  PRIMARY KEY (`PK`)\n")
            out_lines.append(line)
            in_table = False
            continue

    out_lines.append(line)

with gzip.open(output_file, "wt", encoding="utf-8") as fout:
    fout.writelines(out_lines)

print("Modification complete. New file saved as:", output_file)
