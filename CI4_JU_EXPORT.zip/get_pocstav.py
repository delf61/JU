with open("ci4_app/app/Models/PocstavModel.php", "r") as f:
    print(f.read())
