import re

# 1. Update Controller to use hex2bin
with open("ci4_app/app/Controllers/BankStatementController.php", "r") as f:
    controller_content = f.read()

controller_content = controller_content.replace("base64_decode($b)", "hex2bin($b)")
controller_content = controller_content.replace("base64_decode($date)", "hex2bin($date)")

with open("ci4_app/app/Controllers/BankStatementController.php", "w") as f:
    f.write(controller_content)


# 2. Update View (pageLength, bin2hex, remove confirm)
with open("ci4_app/app/Views/bank/index.php", "r") as f:
    view_content = f.read()

view_content = view_content.replace("base64_encode($row['b'])", "bin2hex($row['b'])")
view_content = view_content.replace("base64_encode($row['d'])", "bin2hex($row['d'])")

view_content = view_content.replace(
    '''onclick="return confirm('Naozaj vytvoriť kópiu tohto záznamu?');"''',
    ''
)

view_content = view_content.replace('pageLength: 20', 'pageLength: 15')

with open("ci4_app/app/Views/bank/index.php", "w") as f:
    f.write(view_content)

