with open("ci4_app/app/Config/Routes.php", "r") as f:
    content = f.read()

content = content.replace(
    "'BankStatementController::uiEdit/$1/$2'",
    "'BankStatementController::uiEdit/$1/$2/$3/$4'"
)
content = content.replace(
    "'BankStatementController::uiDelete/$1/$2'",
    "'BankStatementController::uiDelete/$1/$2/$3/$4'"
)
content = content.replace(
    "'BankStatementController::uiCopy/$1/$2'",
    "'BankStatementController::uiCopy/$1/$2/$3/$4'"
)

with open("ci4_app/app/Config/Routes.php", "w") as f:
    f.write(content)
